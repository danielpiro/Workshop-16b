package DomainLayer.Store;

public class DiscountPolicy {
}
