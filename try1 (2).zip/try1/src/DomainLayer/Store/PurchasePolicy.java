package DomainLayer.Store;

public class PurchasePolicy {
}
