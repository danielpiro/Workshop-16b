package DomainLayer.InternalService;

public interface InternalService {
}
