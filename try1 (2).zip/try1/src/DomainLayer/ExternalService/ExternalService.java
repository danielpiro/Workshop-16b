package DomainLayer.ExternalService;

public interface ExternalService {

    public boolean connect();

}
