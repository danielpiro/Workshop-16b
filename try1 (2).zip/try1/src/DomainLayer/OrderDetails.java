package DomainLayer;

public class OrderDetails {
}
