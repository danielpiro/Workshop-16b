package DomainLayer.Roles;

public enum Permission {

    VIEW_AND_RESPOND_TO_USERS,
    VIEW_STORE_HISTORY,
    ADD_PRODUCT,
    EDIT_PRODUCT,
    REMOVE_PRODUCT,
    EDIT_STORE_POLICY,
    ASSIGN_STORE_MANAGER,
    REMOVE_STORE_MANAGER,

}

