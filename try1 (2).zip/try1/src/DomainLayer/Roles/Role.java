package DomainLayer.Roles;

import DomainLayer.User.Subscriber;

public abstract class Role {

    public Subscriber user;

    public Role() {

    }

}
